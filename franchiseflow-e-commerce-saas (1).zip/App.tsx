
import React, { useState } from 'react';
import { UserRole, AuthState } from './types';
import Layout from './components/Layout';
import AdminDashboard from './components/AdminDashboard';
import FranchiseDashboard from './components/FranchiseDashboard';
import CustomerStorefront from './components/CustomerStorefront';
import { MOCK_USERS } from './mockData';

const App: React.FC = () => {
  const [view, setView] = useState<'admin' | 'franchise' | 'customer'>('admin');
  const [auth, setAuth] = useState<AuthState>({
    user: MOCK_USERS[0], 
    isAuthenticated: true
  });

  const handleLogout = () => {
    // In a real app, this would clear JWT and redirect to login
    window.location.reload();
  };

  const renderContent = () => {
    switch (view) {
      case 'admin':
        return <AdminDashboard />;
      case 'franchise':
        // Simulating the owner of Delhi Central
        return <FranchiseDashboard franchiseId="f1" />;
      case 'customer':
        return <CustomerStorefront activeSlug="delhi" />;
      default:
        return <AdminDashboard />;
    }
  };

  return (
    <div className="antialiased selection:bg-indigo-100 selection:text-indigo-900">
      <Layout 
        role={auth.user?.role} 
        onLogout={handleLogout}
        onViewChange={setView}
        tenantName={view === 'customer' ? 'Delhi Central' : undefined}
      >
        <div className="bg-slate-50/30 min-h-screen">
          {/* Simulation of Subdomain Logic */}
          {view === 'customer' && (
            <div className="bg-slate-900 text-indigo-400 text-[9px] py-1 text-center font-black tracking-widest uppercase">
              <i className="fas fa-globe mr-2"></i> Simulated Domain: delhi.franchiseflow.io
            </div>
          )}
          
          {renderContent()}
        </div>
      </Layout>
    </div>
  );
};

export default App;
