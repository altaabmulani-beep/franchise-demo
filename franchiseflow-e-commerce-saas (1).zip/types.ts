
export enum UserRole {
  SUPER_ADMIN = 'SUPER_ADMIN',
  FRANCHISE_OWNER = 'FRANCHISE_OWNER',
  CUSTOMER = 'CUSTOMER'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  franchiseId?: string;
}

export interface Franchise {
  id: string;
  name: string;
  slug: string;
  location: string;
  ownerId: string;
  commissionRate: number;
  isActive: boolean;
  revenue: number;
  totalOrders: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  category: string;
  imageUrl: string;
  totalStock: number;
  sku: string;
}

export interface Order {
  id: string;
  customerId: string;
  franchiseId: string;
  items: {
    productId: string;
    quantity: number;
    priceAtTime: number;
    productName: string;
  }[];
  totalAmount: number;
  status: 'PENDING' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';
  createdAt: string;
  paymentStatus: 'PAID' | 'UNPAID' | 'REFUNDED';
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  type: 'ORDER' | 'STOCK' | 'SYSTEM';
  read: boolean;
  timestamp: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}
