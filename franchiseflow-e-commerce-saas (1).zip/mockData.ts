
import { User, UserRole, Franchise, Product, Order, Notification } from './types';

export const MOCK_USERS: User[] = [
  { id: 'u1', name: 'Alex Rivera', email: 'admin@franchiseflow.io', role: UserRole.SUPER_ADMIN },
  { id: 'u2', name: 'Rajesh Kumar', email: 'delhi@franchiseflow.io', role: UserRole.FRANCHISE_OWNER, franchiseId: 'f1' },
  { id: 'u3', name: 'Sarah Jones', email: 'mumbai@franchiseflow.io', role: UserRole.FRANCHISE_OWNER, franchiseId: 'f2' },
  { id: 'u4', name: 'John Doe', email: 'john@gmail.com', role: UserRole.CUSTOMER },
];

export const MOCK_FRANCHISES: Franchise[] = [
  { id: 'f1', name: 'Delhi Central', slug: 'delhi', location: 'New Delhi, DL', ownerId: 'u2', commissionRate: 0.15, isActive: true, revenue: 45200, totalOrders: 154 },
  { id: 'f2', name: 'Mumbai Express', slug: 'mumbai', location: 'Mumbai, MH', ownerId: 'u3', commissionRate: 0.12, isActive: true, revenue: 32100, totalOrders: 98 },
  { id: 'f3', name: 'Bangalore Hub', slug: 'bangalore', location: 'Bangalore, KA', ownerId: '', commissionRate: 0.10, isActive: false, revenue: 0, totalOrders: 0 },
];

export const MOCK_PRODUCTS: Product[] = [
  { id: 'p1', sku: 'COF-001', name: 'Premium Espresso Beans', description: 'Rich, dark roast beans sourced from organic highland farms.', basePrice: 24.99, category: 'Beverages', imageUrl: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&q=80&w=400', totalStock: 450 },
  { id: 'p2', sku: 'KIT-002', name: 'Cold Brew Professional Kit', description: 'Everything you need to make professional grade cold brew at home.', basePrice: 85.00, category: 'Equipment', imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=400', totalStock: 85 },
  { id: 'p3', sku: 'MUG-003', name: 'Artisan Ceramic Set', description: 'Handcrafted minimalist ceramic mugs, set of 4.', basePrice: 35.99, category: 'Lifestyle', imageUrl: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&q=80&w=400', totalStock: 120 },
  { id: 'p4', sku: 'SYR-004', name: 'Signature Syrup Pack', description: 'Gourmet Vanilla, Caramel, and Hazelnut flavors.', basePrice: 19.99, category: 'Add-ons', imageUrl: 'https://images.unsplash.com/photo-1595981267035-21045a621120?auto=format&fit=crop&q=80&w=400', totalStock: 200 },
];

export const MOCK_ORDERS: Order[] = [
  { id: 'ord-101', customerId: 'u4', franchiseId: 'f1', items: [{ productId: 'p1', quantity: 2, priceAtTime: 24.99, productName: 'Premium Espresso Beans' }], totalAmount: 49.98, status: 'DELIVERED', createdAt: '2023-11-20T10:00:00Z', paymentStatus: 'PAID' },
  { id: 'ord-102', customerId: 'u4', franchiseId: 'f2', items: [{ productId: 'p2', quantity: 1, priceAtTime: 85.00, productName: 'Cold Brew Professional Kit' }], totalAmount: 85.00, status: 'PROCESSING', createdAt: '2023-11-25T14:30:00Z', paymentStatus: 'PAID' },
  { id: 'ord-103', customerId: 'u4', franchiseId: 'f1', items: [{ productId: 'p3', quantity: 1, priceAtTime: 35.99, productName: 'Artisan Ceramic Set' }], totalAmount: 35.99, status: 'PENDING', createdAt: '2023-11-28T09:15:00Z', paymentStatus: 'UNPAID' },
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 'n1', userId: 'u1', message: 'New franchise request from Hyderabad.', type: 'SYSTEM', read: false, timestamp: '2023-11-28T08:00:00Z' },
  { id: 'n2', userId: 'u2', message: 'Stock for Espresso Beans is below 10%.', type: 'STOCK', read: true, timestamp: '2023-11-27T12:00:00Z' },
];
