
import React, { useState } from 'react';
import { MOCK_PRODUCTS, MOCK_FRANCHISES } from '../mockData';

const CustomerStorefront: React.FC<{ activeSlug?: string }> = ({ activeSlug = 'delhi' }) => {
  const [cartCount, setCartCount] = useState(0);
  const activeFranchise = MOCK_FRANCHISES.find(f => f.slug === activeSlug) || MOCK_FRANCHISES[0];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative bg-slate-900 h-[400px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover opacity-50"
            alt="Hero background" 
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="max-w-2xl">
            <span className="inline-block px-3 py-1 bg-indigo-600 text-white text-xs font-bold rounded-full mb-4 uppercase tracking-widest">
              Storefront: {activeFranchise.name}
            </span>
            <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-6">
              Premium Coffee <br/>
              Delivered to <span className="text-indigo-400 italic">Your Door</span>.
            </h1>
            <p className="text-lg text-slate-300 mb-8 max-w-lg">
              Sourcing the finest beans globally, roasted locally by our {activeFranchise.name} experts.
            </p>
            <div className="flex space-x-4">
              <button className="bg-white text-slate-900 px-8 py-3 rounded-full font-bold hover:bg-indigo-50 transition shadow-lg">
                Shop Now
              </button>
              <button className="border border-white/30 text-white px-8 py-3 rounded-full font-bold hover:bg-white/10 transition backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Product Catalog */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-4">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Featured Products</h2>
            <p className="text-slate-500 mt-2">Hand-picked by the {activeFranchise.name} team for you.</p>
          </div>
          <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-xl">
             <button className="px-4 py-2 bg-white text-slate-900 font-bold rounded-lg shadow-sm text-sm transition">All Items</button>
             <button className="px-4 py-2 text-slate-500 font-medium rounded-lg text-sm transition hover:bg-white">Beverages</button>
             <button className="px-4 py-2 text-slate-500 font-medium rounded-lg text-sm transition hover:bg-white">Gears</button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {MOCK_PRODUCTS.map(product => (
            <div key={product.id} className="group cursor-pointer">
              <div className="relative h-64 w-full bg-slate-100 rounded-2xl overflow-hidden mb-4 shadow-sm">
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
                />
                <button 
                  onClick={() => setCartCount(prev => prev + 1)}
                  className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md h-10 w-10 rounded-full flex items-center justify-center text-indigo-600 opacity-0 group-hover:opacity-100 transition-all hover:bg-indigo-600 hover:text-white shadow-lg"
                >
                  <i className="fas fa-plus"></i>
                </button>
                {product.totalStock < 100 && (
                  <span className="absolute top-4 left-4 bg-rose-600 text-white text-[10px] font-bold px-2 py-1 rounded-md uppercase">
                    Low Stock
                  </span>
                )}
              </div>
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{product.name}</h3>
              <p className="text-slate-500 text-sm mb-2 line-clamp-1">{product.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xl font-black text-indigo-600">${product.basePrice.toFixed(2)}</span>
                <div className="flex items-center space-x-1 text-amber-400 text-xs">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star-half-alt"></i>
                  <span className="text-slate-400 ml-1">(42)</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Floating Cart Button */}
      <button className="fixed bottom-8 right-8 bg-indigo-600 text-white p-4 rounded-full shadow-2xl shadow-indigo-400 flex items-center space-x-3 hover:scale-105 transition active:scale-95 group z-50">
        <i className="fas fa-shopping-basket text-xl"></i>
        <span className="font-bold pr-2">{cartCount} Items</span>
        {cartCount > 0 && (
          <div className="absolute -top-2 -right-2 bg-rose-500 h-6 w-6 rounded-full flex items-center justify-center border-2 border-white text-[10px] font-bold animate-bounce">
            {cartCount}
          </div>
        )}
      </button>

      {/* Newsletter */}
      <div className="bg-indigo-50 py-16 border-y border-indigo-100">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">Join our Coffee Club</h2>
          <p className="text-slate-600 mb-8">Get exclusive offers from your local {activeFranchise.name} outlet.</p>
          <div className="flex flex-col sm:flex-row gap-4">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="flex-grow px-6 py-3 rounded-full border border-indigo-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            <button className="bg-indigo-600 text-white px-10 py-3 rounded-full font-bold hover:bg-indigo-700 transition">
              Subscribe
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerStorefront;
