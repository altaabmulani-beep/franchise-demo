
import React, { useState } from 'react';
import { MOCK_ORDERS, MOCK_PRODUCTS, MOCK_FRANCHISES } from '../mockData';
import { Order } from '../types';
import InvoiceGenerator from './InvoiceGenerator';

const FranchiseDashboard: React.FC<{ franchiseId: string }> = ({ franchiseId }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const franchise = MOCK_FRANCHISES.find(f => f.id === franchiseId) || MOCK_FRANCHISES[0];
  const localOrders = MOCK_ORDERS.filter(o => o.franchiseId === franchiseId);
  const totalRevenue = localOrders.reduce((acc, o) => acc + o.totalAmount, 0);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 animate-in slide-in-from-bottom duration-500 relative">
      
      {selectedOrder && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl bg-white rounded-3xl overflow-hidden max-h-[90vh] overflow-y-auto">
            <button 
              onClick={() => setSelectedOrder(null)}
              className="absolute top-6 right-6 h-10 w-10 bg-slate-100 rounded-full flex items-center justify-center hover:bg-slate-200 transition"
            >
              <i className="fas fa-times"></i>
            </button>
            <div className="p-8">
              <h2 className="text-2xl font-black mb-8">Order & Invoice View</h2>
              <InvoiceGenerator order={selectedOrder} franchise={franchise} />
              <div className="mt-8 flex justify-center space-x-4">
                <button className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 transition">
                  <i className="fas fa-print mr-2"></i> Print Invoice
                </button>
                <button className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 shadow-lg shadow-slate-200 transition">
                  <i className="fas fa-envelope mr-2"></i> Send to Customer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-900">Franchise Terminal</h1>
          <p className="text-slate-500 font-medium">Outlet: <span className="text-indigo-600">{franchise.name}</span></p>
        </div>
        <div className="flex items-center space-x-3 text-[10px] bg-indigo-50 border border-indigo-100 px-4 py-2 rounded-full text-indigo-700 font-black uppercase tracking-widest">
          <div className="h-2 w-2 bg-emerald-500 rounded-full animate-pulse"></div>
          <span>Systems Nominal</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Gross Local Sales', value: `$${totalRevenue.toFixed(2)}`, icon: 'fa-chart-pie', color: 'bg-indigo-600', trend: '+5.4%' },
          { label: 'Active Queue', value: localOrders.filter(o => o.status !== 'DELIVERED').length, icon: 'fa-layer-group', color: 'bg-amber-500', trend: 'In Progress' },
          { label: 'Store Earnings', value: `$${(totalRevenue * (1 - franchise.commissionRate)).toFixed(2)}`, icon: 'fa-hand-holding-dollar', color: 'bg-emerald-600', trend: 'Net Profit' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 hover:border-indigo-100 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.color} p-4 rounded-2xl text-white shadow-lg`}>
                <i className={`fas ${stat.icon} text-xl`}></i>
              </div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{stat.trend}</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 font-black uppercase tracking-widest mb-1">{stat.label}</p>
              <h3 className="text-2xl font-bold text-slate-900">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Order Fulfillment Center */}
        <div className="lg:col-span-3 bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-slate-50 flex justify-between items-center">
            <h3 className="text-lg font-bold">Fulfillment Queue</h3>
            <div className="flex space-x-2">
              <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Orders: {localOrders.length}</span>
            </div>
          </div>
          <div className="p-4 space-y-4">
            {localOrders.map(order => (
              <div 
                key={order.id} 
                onClick={() => setSelectedOrder(order)}
                className="group flex items-center justify-between p-6 bg-slate-50 rounded-2xl hover:bg-indigo-50 transition cursor-pointer border border-transparent hover:border-indigo-100"
              >
                <div className="flex items-center space-x-6">
                  <div className="h-12 w-12 bg-white rounded-2xl flex items-center justify-center border shadow-sm group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <i className="fas fa-box"></i>
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-900 uppercase tracking-tighter">#{order.id.split('-')[1]}</p>
                    <p className="text-xs text-slate-500 font-medium">Customer ID: {order.customerId}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2">
                  <span className="text-sm font-bold text-slate-900">${order.totalAmount.toFixed(2)}</span>
                  <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${order.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Local Inventory Allocation */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-8 border-b border-slate-50">
              <h3 className="text-lg font-bold">Allocated Stock</h3>
            </div>
            <div className="divide-y divide-slate-50">
              {MOCK_PRODUCTS.slice(0, 4).map(prod => (
                <div key={prod.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition">
                  <div className="flex items-center space-x-4">
                    <img src={prod.imageUrl} alt={prod.name} className="h-10 w-10 rounded-xl object-cover shadow-sm" />
                    <div>
                      <p className="text-sm font-bold text-slate-900">{prod.name}</p>
                      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">SKU: {prod.sku}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-slate-900">42 Units</p>
                    <div className="w-20 bg-slate-100 rounded-full h-1 mt-2">
                      <div className="bg-indigo-500 h-1 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-6 bg-slate-50/50">
               <button className="w-full py-3 bg-slate-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 transition shadow-lg">
                 Restock Request
               </button>
            </div>
          </div>

          <div className="bg-indigo-900 rounded-3xl p-8 text-white shadow-xl">
             <h4 className="text-sm font-black uppercase tracking-widest mb-4">Franchise Help</h4>
             <p className="text-xs text-indigo-200 leading-relaxed mb-6">Need assistance with your local operations? Our HQ support team is available 24/7.</p>
             <button className="w-full py-3 border border-indigo-500 text-indigo-300 rounded-xl text-xs font-bold hover:bg-indigo-800 transition">
               Open HQ Ticket
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FranchiseDashboard;
