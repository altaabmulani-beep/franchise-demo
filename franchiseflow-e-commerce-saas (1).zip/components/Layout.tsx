
import React, { ReactNode } from 'react';
import { UserRole } from '../types';

interface LayoutProps {
  children: ReactNode;
  role?: UserRole;
  tenantName?: string;
  onLogout: () => void;
  onViewChange: (view: 'admin' | 'franchise' | 'customer') => void;
}

const Layout: React.FC<LayoutProps> = ({ children, role, tenantName, onLogout, onViewChange }) => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation Header */}
      <nav className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-3">
              <div className="bg-indigo-600 h-8 w-8 rounded-lg flex items-center justify-center">
                <i className="fas fa-layer-group text-white text-sm"></i>
              </div>
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
                FranchiseFlow {tenantName ? `| ${tenantName}` : ''}
              </span>
            </div>

            <div className="hidden md:flex items-center space-x-6">
              <button 
                onClick={() => onViewChange('customer')}
                className="text-slate-600 hover:text-indigo-600 font-medium transition-colors"
              >
                Storefront
              </button>
              <button 
                onClick={() => onViewChange('admin')}
                className="text-slate-600 hover:text-indigo-600 font-medium transition-colors"
              >
                Super Admin
              </button>
              <button 
                onClick={() => onViewChange('franchise')}
                className="text-slate-600 hover:text-indigo-600 font-medium transition-colors"
              >
                Franchise Panel
              </button>
              
              <div className="h-6 w-px bg-slate-200"></div>
              
              <button 
                onClick={onLogout}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors font-medium text-sm"
              >
                Sign Out
              </button>
            </div>
            
            {/* Mobile Menu Icon */}
            <div className="md:hidden">
              <i className="fas fa-bars text-xl text-slate-600"></i>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center text-slate-500 text-sm">
          <p>© 2024 FranchiseFlow SaaS. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-indigo-600">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-600">Terms of Service</a>
            <a href="#" className="hover:text-indigo-600">Help Center</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
