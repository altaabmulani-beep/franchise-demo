
import React, { useState, useEffect } from 'react';
import { MOCK_FRANCHISES, MOCK_PRODUCTS, MOCK_ORDERS } from '../mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { aiService } from '../services/geminiService';
import ProductManagement from './ProductManagement';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'franchises' | 'orders'>('overview');
  const [insights, setInsights] = useState<string>("Analyzing ecosystem data...");
  const [loadingInsights, setLoadingInsights] = useState(false);

  useEffect(() => {
    const fetchInsights = async () => {
      setLoadingInsights(true);
      const res = await aiService.getPerformanceInsights({ 
        revenue: MOCK_FRANCHISES.map(f => f.revenue),
        orders: MOCK_ORDERS.length 
      });
      setInsights(res);
      setLoadingInsights(false);
    };
    fetchInsights();
  }, []);

  const chartData = MOCK_FRANCHISES.map(f => ({ name: f.slug, revenue: f.revenue }));

  return (
    <div className="min-h-screen bg-slate-50/50">
      {/* Sub-nav tabs */}
      <div className="bg-white border-b px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex space-x-8">
          {(['overview', 'products', 'franchises', 'orders'] as const).map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 text-sm font-bold uppercase tracking-widest transition-all border-b-2 ${activeTab === tab ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8">
        {activeTab === 'overview' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-3xl font-black text-slate-900 tracking-tight">Global Dashboard</h1>
                <p className="text-slate-500">Real-time health monitor of the FranchiseFlow ecosystem.</p>
              </div>
              <div className="flex space-x-3">
                <button className="bg-white border text-slate-700 px-4 py-2 rounded-xl hover:bg-slate-50 transition text-sm font-bold shadow-sm flex items-center">
                  <i className="fas fa-calendar-alt mr-2"></i> Last 30 Days
                </button>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Ecosystem Revenue', value: '$77,300', icon: 'fa-vault', color: 'text-indigo-600', bg: 'bg-indigo-50', change: '+14%' },
                { label: 'Network Nodes', value: MOCK_FRANCHISES.length, icon: 'fa-network-wired', color: 'text-violet-600', bg: 'bg-violet-50', change: '0%' },
                { label: 'Global Inventory', value: '855 Units', icon: 'fa-boxes-stacked', color: 'text-amber-600', bg: 'bg-amber-50', change: '-4%' },
                { label: 'Processing Orders', value: MOCK_ORDERS.filter(o => o.status === 'PROCESSING').length, icon: 'fa-spinner', color: 'text-rose-600', bg: 'bg-rose-50', change: '+12' },
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group hover:border-indigo-100 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                      <h3 className="text-3xl font-bold tracking-tight">{stat.value}</h3>
                    </div>
                    <div className={`${stat.bg} ${stat.color} p-4 rounded-2xl transition-transform group-hover:scale-110`}>
                      <i className={`fas ${stat.icon} text-xl`}></i>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-xs font-bold">
                    <span className={stat.change.startsWith('+') ? 'text-emerald-500' : 'text-slate-400'}>{stat.change}</span>
                    <span className="text-slate-400 ml-2 font-medium italic">from yesterday</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Revenue Visualization */}
              <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-bold">Franchise Revenue Distribution</h3>
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-400">
                    <div className="h-2 w-2 rounded-full bg-indigo-500"></div>
                    <span>Net Sales</span>
                  </div>
                </div>
                <div className="h-[320px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12, fontWeight: 700}} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                      <Tooltip 
                        cursor={{fill: '#f8fafc'}}
                        contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px' }}
                      />
                      <Bar dataKey="revenue" fill="#6366f1" radius={[8, 8, 0, 0]} barSize={48}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#6366f1' : '#a855f7'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* AI Strategic Insights */}
              <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
                <div className="absolute top-[-20px] right-[-20px] h-40 w-40 bg-indigo-500/20 rounded-full blur-3xl"></div>
                <div className="flex items-center space-x-3 mb-6">
                  <div className="bg-indigo-500/20 p-2 rounded-lg">
                    <i className="fas fa-microchip text-indigo-400"></i>
                  </div>
                  <h3 className="text-lg font-bold">Strategic Insights</h3>
                </div>
                
                <div className="space-y-6">
                  {loadingInsights ? (
                    <div className="flex flex-col space-y-3">
                      <div className="h-4 bg-slate-800 rounded w-full animate-pulse"></div>
                      <div className="h-4 bg-slate-800 rounded w-3/4 animate-pulse"></div>
                      <div className="h-4 bg-slate-800 rounded w-5/6 animate-pulse"></div>
                    </div>
                  ) : (
                    <div className="text-slate-300 text-sm leading-relaxed whitespace-pre-line italic font-medium">
                      "{insights}"
                    </div>
                  )}
                  
                  <div className="pt-6 border-t border-slate-800 space-y-4">
                    <p className="text-[10px] text-slate-500 uppercase font-black tracking-widest">Growth Recommendations</p>
                    <div className="bg-indigo-500/10 border border-indigo-500/20 p-4 rounded-2xl flex items-start space-x-3">
                      <i className="fas fa-rocket text-indigo-400 mt-1"></i>
                      <div>
                        <p className="text-xs font-bold text-white">Scale Bangalore Hub</p>
                        <p className="text-[10px] text-slate-400 mt-1">Market research suggests high demand in KA region. Onboard owner soon.</p>
                      </div>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => {
                    setLoadingInsights(true);
                    aiService.getPerformanceInsights({}).then(res => {
                      setInsights(res);
                      setLoadingInsights(false);
                    });
                  }}
                  className="mt-8 w-full py-3 bg-white text-slate-900 font-black text-xs uppercase tracking-widest rounded-xl hover:bg-slate-100 transition transform hover:-translate-y-1"
                >
                  Regenerate Strategy
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && <ProductManagement />}

        {activeTab === 'franchises' && (
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-right duration-300">
            <div className="p-8 border-b border-slate-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">Network Nodes</h3>
              <button className="bg-slate-900 text-white px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-widest">
                Add Node
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 text-slate-400 text-[10px] uppercase font-black tracking-widest">
                  <tr>
                    <th className="px-8 py-5">Node Identity</th>
                    <th className="px-8 py-5">Geo-Location</th>
                    <th className="px-8 py-5">Profit Share</th>
                    <th className="px-8 py-5">Health</th>
                    <th className="px-8 py-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {MOCK_FRANCHISES.map(f => (
                    <tr key={f.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-8 py-6">
                        <div className="flex items-center space-x-3">
                          <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                            {f.name.charAt(0)}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{f.name}</p>
                            <p className="text-xs text-slate-400">{f.slug}.franchiseflow.io</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-slate-500 font-medium">{f.location}</td>
                      <td className="px-8 py-6 font-bold text-slate-700">{(f.commissionRate * 100).toFixed(0)}%</td>
                      <td className="px-8 py-6">
                        <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${f.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-400'}`}>
                          {f.isActive ? 'Online' : 'Offline'}
                        </span>
                      </td>
                      <td className="px-8 py-6 text-right">
                        <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-300 hover:text-indigo-600 transition">
                          <i className="fas fa-ellipsis-v"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
