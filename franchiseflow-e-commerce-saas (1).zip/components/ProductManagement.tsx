
import React, { useState } from 'react';
import { Product } from '../types';
import { MOCK_PRODUCTS } from '../mockData';
import { aiService } from '../services/geminiService';

const ProductManagement: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [isAdding, setIsAdding] = useState(false);
  const [newProductName, setNewProductName] = useState('');
  const [generatedDesc, setGeneratedDesc] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateDescription = async () => {
    if (!newProductName) return;
    setIsGenerating(true);
    const desc = await aiService.generateProductDescription(newProductName);
    setGeneratedDesc(desc || '');
    setIsGenerating(false);
  };

  return (
    <div className="p-8 space-y-8 animate-in slide-in-from-right duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Global Inventory</h2>
          <p className="text-slate-500 text-sm">Master catalog for all franchise nodes.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg shadow-indigo-200"
        >
          <i className="fas fa-plus mr-2"></i> Add Master Product
        </button>
      </div>

      {isAdding && (
        <div className="bg-white border p-6 rounded-2xl shadow-sm border-indigo-100 animate-in fade-in zoom-in duration-200">
          <div className="flex justify-between items-start mb-6">
            <h3 className="font-bold text-lg">New Product Blueprint</h3>
            <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600">
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Product Name</label>
                <input 
                  type="text" 
                  value={newProductName}
                  onChange={(e) => setNewProductName(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-50 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" 
                  placeholder="e.g. Nitro Cold Brew Concentrate"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex justify-between">
                  AI Generated Description
                  <button 
                    onClick={handleGenerateDescription}
                    disabled={isGenerating || !newProductName}
                    className="text-indigo-600 hover:underline disabled:text-slate-300 transition"
                  >
                    {isGenerating ? 'Thinking...' : 'Magic Generate'}
                  </button>
                </label>
                <textarea 
                  value={generatedDesc}
                  onChange={(e) => setGeneratedDesc(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-50 border rounded-lg h-24 focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                  placeholder="The AI will help you write a punchy description..."
                ></textarea>
              </div>
            </div>
            <div className="space-y-4">
               <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Category</label>
                    <select className="w-full px-4 py-2 bg-slate-50 border rounded-lg">
                      <option>Beverages</option>
                      <option>Equipment</option>
                      <option>Lifestyle</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Base Price ($)</label>
                    <input type="number" className="w-full px-4 py-2 bg-slate-50 border rounded-lg" placeholder="29.99" />
                  </div>
               </div>
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Initial Master Stock</label>
                  <input type="number" className="w-full px-4 py-2 bg-slate-50 border rounded-lg" placeholder="1000" />
               </div>
               <button className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-md hover:bg-indigo-700 transition mt-4">
                 Save to Master Catalog
               </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map(product => (
          <div key={product.id} className="bg-white border rounded-2xl overflow-hidden hover:shadow-xl transition-all group">
            <div className="h-48 relative overflow-hidden">
              <img src={product.imageUrl} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" alt="" />
              <div className="absolute top-2 right-2 bg-white/80 backdrop-blur px-2 py-1 rounded text-[10px] font-bold">
                {product.sku}
              </div>
            </div>
            <div className="p-4">
              <h4 className="font-bold text-slate-800">{product.name}</h4>
              <p className="text-xs text-slate-500 line-clamp-2 mt-1 mb-3">{product.description}</p>
              <div className="flex justify-between items-center border-t pt-3 mt-3">
                <span className="font-bold text-indigo-600">${product.basePrice.toFixed(2)}</span>
                <span className="text-[10px] text-slate-400 bg-slate-50 px-2 py-1 rounded uppercase font-bold">Stock: {product.totalStock}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="py-2 bg-slate-100 text-slate-700 rounded-lg text-[10px] font-bold hover:bg-slate-200 uppercase">Manage Stock</button>
                <button className="py-2 bg-indigo-50 text-indigo-600 rounded-lg text-[10px] font-bold hover:bg-indigo-100 uppercase">Edit Detail</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductManagement;
