
import React from 'react';
import { Order, Franchise } from '../types';

interface InvoiceProps {
  order: Order;
  franchise: Franchise;
}

const InvoiceGenerator: React.FC<InvoiceProps> = ({ order, franchise }) => {
  return (
    <div className="bg-white p-8 max-w-2xl mx-auto border shadow-sm font-serif">
      <div className="flex justify-between items-start mb-8 border-b pb-8">
        <div>
          <h2 className="text-2xl font-bold uppercase tracking-widest text-slate-800">Invoice</h2>
          <p className="text-slate-500 text-sm mt-1"># {order.id.toUpperCase()}</p>
        </div>
        <div className="text-right">
          <h3 className="font-bold text-lg text-indigo-600">FranchiseFlow</h3>
          <p className="text-xs text-slate-500">{franchise.name}</p>
          <p className="text-xs text-slate-500">{franchise.location}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8 text-sm">
        <div>
          <p className="font-bold text-slate-400 uppercase text-[10px] mb-2">Billed To</p>
          <p className="font-bold">Customer ID: {order.customerId}</p>
          <p className="text-slate-500">Contact: via Platform</p>
        </div>
        <div className="text-right">
          <p className="font-bold text-slate-400 uppercase text-[10px] mb-2">Order Date</p>
          <p className="font-bold">{new Date(order.createdAt).toLocaleDateString()}</p>
          <p className="text-slate-500">Status: {order.status}</p>
        </div>
      </div>

      <table className="w-full mb-8 text-sm text-left">
        <thead className="bg-slate-50 border-y">
          <tr>
            <th className="py-3 px-2">Item Description</th>
            <th className="py-3 px-2 text-center">Qty</th>
            <th className="py-3 px-2 text-right">Price</th>
            <th className="py-3 px-2 text-right">Total</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {order.items.map((item, i) => (
            <tr key={i}>
              <td className="py-4 px-2 font-medium">{item.productName}</td>
              <td className="py-4 px-2 text-center">{item.quantity}</td>
              <td className="py-4 px-2 text-right">${item.priceAtTime.toFixed(2)}</td>
              <td className="py-4 px-2 text-right font-bold">${(item.quantity * item.priceAtTime).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="flex justify-end">
        <div className="w-1/2 space-y-3 text-sm">
          <div className="flex justify-between text-slate-500">
            <span>Subtotal</span>
            <span>${order.totalAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-slate-500">
            <span>Tax (0%)</span>
            <span>$0.00</span>
          </div>
          <div className="flex justify-between pt-3 border-t text-lg font-bold text-indigo-600">
            <span>Total Amount</span>
            <span>${order.totalAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <div className="mt-16 text-center text-[10px] text-slate-400 uppercase tracking-widest">
        Thank you for choosing {franchise.name}
      </div>
    </div>
  );
};

export default InvoiceGenerator;
