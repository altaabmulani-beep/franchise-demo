
import { MOCK_USERS, MOCK_FRANCHISES, MOCK_PRODUCTS, MOCK_ORDERS } from '../mockData';
import { Product, Order, Franchise } from '../types';

/**
 * SIMULATED REST API ARCHITECTURE
 * This file mimics the behavior of a backend service (Express/MongoDB).
 * In a real environment, these would be fetch() or axios calls.
 */

export const api = {
  // --- AUTH ---
  login: async (email: string) => {
    const user = MOCK_USERS.find(u => u.email === email);
    if (!user) throw new Error("Invalid credentials");
    return { user, token: "simulated-jwt-token" };
  },

  // --- PRODUCTS ---
  getProducts: async () => MOCK_PRODUCTS,
  updateProduct: async (id: string, updates: Partial<Product>) => {
    console.log(`Updating product ${id} with`, updates);
    return { success: true };
  },

  // --- FRANCHISES ---
  getFranchises: async () => MOCK_FRANCHISES,
  getFranchiseBySlug: async (slug: string) => MOCK_FRANCHISES.find(f => f.slug === slug),

  // --- ORDERS ---
  getOrders: async (franchiseId?: string) => {
    if (franchiseId) return MOCK_ORDERS.filter(o => o.franchiseId === franchiseId);
    return MOCK_ORDERS;
  },
  createOrder: async (orderData: Partial<Order>) => {
    console.log("Creating order in DB...", orderData);
    return { ...orderData, id: `ord-${Math.floor(Math.random() * 1000)}`, createdAt: new Date().toISOString() };
  },

  // --- ANALYTICS ---
  getGlobalStats: async () => {
    const revenue = MOCK_FRANCHISES.reduce((acc, f) => acc + f.revenue, 0);
    const orders = MOCK_ORDERS.length;
    return { revenue, orders, activeFranchises: MOCK_FRANCHISES.filter(f => f.isActive).length };
  }
};
