
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async getPerformanceInsights(data: any) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze the following franchise performance data and provide 3 actionable business insights in bullet points: ${JSON.stringify(data)}`,
        config: {
          temperature: 0.7,
        },
      });
      return response.text || "No insights available at this time.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "Unable to generate insights.";
    }
  }

  async generateProductDescription(productName: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a short, punchy marketing description for a high-end e-commerce product named: ${productName}. Max 20 words.`,
      });
      return response.text;
    } catch (error) {
      return "A premium product for discerning customers.";
    }
  }
}

export const aiService = new GeminiService();
