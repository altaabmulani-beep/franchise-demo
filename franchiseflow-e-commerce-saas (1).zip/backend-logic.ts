
/**
 * MERN BACKEND ARCHITECTURE (CONCEPTUAL REFERENCE)
 * This file provides the MongoDB schemas and Express routes as requested.
 * 
 * TECH STACK:
 * - MongoDB: Multi-tenant indexing
 * - Express: REST API
 * - Node: Core logic
 */

/*
// MONGODB SCHEMAS (Mongoose)

const UserSchema = new Schema({
  name: String,
  email: { type: String, unique: true },
  password: { type: String, select: false },
  role: { type: String, enum: ['SUPER_ADMIN', 'FRANCHISE_OWNER', 'CUSTOMER'] },
  franchiseId: { type: Schema.Types.ObjectId, ref: 'Franchise' }
});

const FranchiseSchema = new Schema({
  name: String,
  slug: { type: String, unique: true }, // For subdomain matching
  location: String,
  ownerId: { type: Schema.Types.ObjectId, ref: 'User' },
  commissionRate: Number,
  inventory: [{
    productId: { type: Schema.Types.ObjectId, ref: 'Product' },
    quantity: Number
  }]
});

const OrderSchema = new Schema({
  customerId: { type: Schema.Types.ObjectId, ref: 'User' },
  franchiseId: { type: Schema.Types.ObjectId, ref: 'Franchise' },
  items: [{
    productId: Schema.Types.ObjectId,
    quantity: Number,
    price: Number
  }],
  status: String,
  total: Number
});

// EXPRESS ROUTES

// 1. Authentication Middleware
// router.use(verifyJWT);

// 2. Multi-tenant Subdomain Logic (Middleware)
// app.use((req, res, next) => {
//   const host = req.get('host'); // e.g., delhi.brand.com
//   const subdomain = host.split('.')[0];
//   req.franchiseSlug = subdomain;
//   next();
// });

// 3. API Endpoints
// router.get('/products', async (req, res) => {
//   const franchise = await Franchise.findOne({ slug: req.franchiseSlug });
//   const products = await Product.find({ _id: { $in: franchise.inventory.map(i => i.productId) } });
//   res.json(products);
// });
*/

export const DEPLOYMENT_INSTRUCTIONS = `
1. PROVISION MONGODB ATLAS: Create a cluster and get connection string.
2. BACKEND SETUP: Install express, mongoose, cors, dotenv, jsonwebtoken.
3. SUBDOMAIN ROUTING: Set up a Wildcard DNS record (*.yourdomain.com) pointing to your server.
4. SERVER CONFIG: Use Nginx to proxy requests. Nginx should pass the Host header to Node.
5. FRONTEND: Deploy React to a CDN or your VPS. Ensure CORS allows the subdomains.
6. ENV VARIABLES: Set API_KEY (Gemini), MONGO_URI, and JWT_SECRET.
`;
